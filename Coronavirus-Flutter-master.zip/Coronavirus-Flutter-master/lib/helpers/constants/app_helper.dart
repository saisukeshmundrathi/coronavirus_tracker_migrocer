import 'dart:math';

class AppHelper {
  static double radiansFrom({degree: int}) {
    return degree * pi / 180.0;
  }
}