abstract class BaseViewModel {
  void dispose();
}
