# Coronavirus  

A Flutter app to track Coronavirus outbreak.

## Getting Started  

-For android add your map key to ```AndroidManifest.xml``` and for iOS add your key to ```AppDelegate.swift```.

-Run the app!.


## Screenshots  

<table>
  <tbody>
    <tr>
      <th><img src="https://raw.githubusercontent.com/Abedalkareem/Coronavirus-Flutter/master/screenshots/screenshot1.png"/></th>
      <th><img src="https://raw.githubusercontent.com/Abedalkareem/Coronavirus-Flutter/master/screenshots/screenshot2.png"/></th>
      <th><img src="https://raw.githubusercontent.com/Abedalkareem/Coronavirus-Flutter/master/screenshots/screenshot3.png"/></th>
    </tr>
    <tr>
      <th><img src="https://raw.githubusercontent.com/Abedalkareem/Coronavirus-Flutter/master/screenshots/screenshot4.png"/></th>
      <th><img src="https://raw.githubusercontent.com/Abedalkareem/Coronavirus-Flutter/master/screenshots/screenshot5.png"/></th>
      <th><img src="https://raw.githubusercontent.com/Abedalkareem/Coronavirus-Flutter/master/screenshots/screenshot6.png"/></th>
    </tr>
  </tbody>
</table>